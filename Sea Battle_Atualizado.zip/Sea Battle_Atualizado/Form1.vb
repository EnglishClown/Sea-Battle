﻿Public Class Form1
    Dim Pic As PictureBox
    Dim Aux As PictureBox
    Dim VecX() = {145, 365, 662, 1002}
    Dim Num() = {1, 1, 1, 1}
    Dim ContLancha As Integer = 0
    Dim ContSub As Integer = 0
    Dim ContBattle As Integer = 0
    Dim ContPort As Integer = 0
    Dim Space As Integer
    Dim Box As String = String.Empty
    Dim Flag As Boolean = True
    Dim BloodyController As Boolean = False
    Dim HitLancha As Integer = 0
    Dim HitSub As Integer = 0
    Dim HitBattle As Integer = 0
    Dim HitPort As Integer = 0
    Dim HitLanchaPlayer As Integer = 0
    Dim HitSubPlayer As Integer = 0
    Dim HitBattlePlayer As Integer = 0
    Dim HitPortPlayer As Integer = 0
    Dim Ship() = {4, 3, 3, 2, 2, 2, 1, 1, 1, 1}
    Dim FormMess As New Form4

    Private Sub Form1_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles MyBase.KeyDown
        If e.KeyCode = Keys.Escape Then
            Me.Close()
            Form2.Close()
            Form3.Close()
        End If
    End Sub
    Dim PersonalCount As Integer = 1
    Dim Pop As String = String.Empty
    Dim BigCount As Integer = 1

    Dim Counting As Integer = 1
    Dim Lab As Label

    Public Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Dim Wt As Integer = Screen.PrimaryScreen.Bounds.Width
        Dim Ht As Integer = Screen.PrimaryScreen.Bounds.Height
        Me.Size = New Drawing.Size(Wt, Ht)
        'PictureBox1.Location = New Point((CInt(Wt / 2) - 176), (CInt(Ht / 2) - 150))

        Dim Picture As PictureBox
        'SetStyle(ControlStyles.OptimizedDoubleBuffer, True)
        Dim Letra As String = "psba"
        For I As Integer = 0 To 3
            Picture = New PictureBox
            Lab = New Label
            Lab.Size = New Drawing.Size(55, 55)
            Lab.Location = New Point(VecX(I) + (55 * PersonalCount) + 10, 35)
            Lab.Font = New Font("Arial", 20,
                    FontStyle.Bold)
            Lab.Text = ""
            Lab.ForeColor = Color.Red
            Lab.Name = "Lab" & PersonalCount
            Lab.BackColor = Color.Transparent
            Lab.BringToFront()
            Me.Controls.Add(Lab)
            Picture.Size = New Drawing.Size((55 * PersonalCount), 55)
            Picture.Location = New Point(VecX(I), 22)
            Picture.Name = Letra(I) & Num(I) & "d_fw"
            Picture.BackColor = Color.Transparent
            Picture.BackgroundImageLayout = ImageLayout.Stretch
            Picture.BackgroundImage = My.Resources.ResourceManager.GetObject(Letra(I) & "d_fw")
            Picture.BorderStyle = BorderStyle.None
            Picture.BringToFront()
            Me.Controls.Add(Picture)
            AddHandler Picture.MouseDown, AddressOf Picture_MouseDown
            AddHandler Picture.Click, AddressOf Clicks
            PersonalCount += 1
        Next

        Dim Diff As Integer = Wt - Label40.Location.X
        Diff = CInt(Diff / 2)

        Dim x As Integer = 60 + Diff
        Dim y As Integer = 164

        For I As Integer = 0 To 9
            For J As Integer = 0 To 9
                Picture = New PictureBox
                Picture.Name = "Pic" & I & J
                Picture.Location = New Point(x, y)
                Picture.Size = New Drawing.Size(56, 55)
                Picture.BackgroundImageLayout = ImageLayout.Stretch
                Picture.BackColor = Color.Transparent
                Picture.BorderStyle = BorderStyle.FixedSingle
                Picture.Tag = 0
                Picture.AllowDrop = True
                Picture.BringToFront()
                Me.Controls.Add(Picture)
                AddHandler Picture.DragEnter, AddressOf Picture_DragEnter
                AddHandler Picture.DragDrop, AddressOf Picture_DragDrop
                AddHandler Picture.Click, AddressOf Clicks
                x += 55
            Next
            x = 60 + Diff
            y += 55
        Next

        For I As Integer = 2 To 11
            CType(Me.Controls.Find("Label" & I, False)(0), Label).Location = New Point(CType(Me.Controls.Find("Label" & I, False)(0), Label).Location.X + Diff, CType(Me.Controls.Find("Label" & I, False)(0), Label).Location.Y)
        Next
        For I As Integer = 12 To 21
            CType(Me.Controls.Find("Label" & I, False)(0), Label).Location = New Point(CType(Me.Controls.Find("Label" & I, False)(0), Label).Location.X + Diff, CType(Me.Controls.Find("Label" & I, False)(0), Label).Location.Y)
        Next
        Rotation.Location = New Point(Rotation.Location.X + Diff, Rotation.Location.Y)


        x = 757
        y = 164

        For I As Integer = 0 To 9
            For J As Integer = 0 To 9
                Picture = New PictureBox
                Picture.Name = "C" & I & J
                Picture.Location = New Point(x, y)
                Picture.Size = New Drawing.Size(56, 55)
                Picture.BackgroundImageLayout = ImageLayout.Stretch
                Picture.BackColor = Color.Transparent
                Picture.BorderStyle = BorderStyle.FixedSingle
                Picture.Tag = 0
                Picture.BringToFront()
                Me.Controls.Add(Picture)
                AddHandler Picture.Click, AddressOf ShootToPc
                AddHandler Picture.Click, AddressOf Clicks
                x += 55
            Next
            x = 757
            y += 55
        Next

        InitialPosition()
        Rotation.BackgroundImage = My.Resources.rot
        'Form3.BringToFront()
    End Sub

    Public Sub Clicks(sender As Object, e As EventArgs) Handles MyBase.Click
        If (Counting = 1) Then
            Form3.ShowDialog()
            Counting += 1
        End If
    End Sub

    Dim AuxiliarLetras As String = "abbssspppp"
    Private Sub InitialPosition()
        Dim Direction As Integer = 0
        Dim IniFlag As Boolean
        Dim Line As Integer
        Dim Column As Integer
        Dim BlaBlaCount As Integer = 0
        Randomize()
        While (BlaBlaCount < 10)
            'CInt((upperbound - lowerbound + 1) * Rnd + lowerbound)
            Direction = CInt((1 - 0 + 1) * Rnd() + 0)
            '0 - Direito |-| 1 - Rodado
            If (Direction = 0) Then
                IniFlag = False
                While (IniFlag = False)
                    Pop = AuxiliarLetras(BlaBlaCount)
                    Column = CInt((9 - 0 + 1) * Rnd() + 0)
                    If (Column <= (10 - Ship(BlaBlaCount))) Then
                        Line = CInt((9 * Rnd()))
                        Space = Ship(BlaBlaCount)
                        Box = "C"
                        Dim Result As Boolean = Organize(Line, Column)
                        If (Result = True) Then
                            IniFlag = True
                            For I As Integer = 0 To (Ship(BlaBlaCount) - 1)
                                'CType(Me.Controls.Find("C" & Line & (Column + I), False)(0), PictureBox).BackgroundImage = My.Resources.ResourceManager.GetObject(AuxiliarLetras(BlaBlaCount) & (I + 1) & "d_fw")
                                CType(Me.Controls.Find("C" & Line & (Column + I), False)(0), PictureBox).Tag = Ship(BlaBlaCount)
                            Next
                            BlaBlaCount += 1
                        End If
                    End If
                End While
            End If
            If (Direction = 1) Then
                IniFlag = False
                While (IniFlag = False)
                    Pop = AuxiliarLetras(BlaBlaCount)
                    Line = CInt((9 - 0 + 1) * Rnd() + 0)
                    If (Line <= (10 - Ship(BlaBlaCount))) Then
                        Column = CInt((9 * Rnd()))
                        Space = Ship(BlaBlaCount)
                        Box = "C"
                        Dim Result As Boolean = RotationOrganize(Line, Column)
                        If (Result = True) Then
                            IniFlag = True
                            For I As Integer = 0 To (Ship(BlaBlaCount) - 1)
                                'CType(Me.Controls.Find("C" & (Line + I) & Column, False)(0), PictureBox).BackgroundImage = My.Resources.ResourceManager.GetObject(AuxiliarLetras(BlaBlaCount) & (I + 1) & "r_fw")
                                CType(Me.Controls.Find("C" & (Line + I) & Column, False)(0), PictureBox).Tag = Ship(BlaBlaCount)
                            Next
                            BlaBlaCount += 1
                        End If
                    End If
                End While
            End If
        End While
    End Sub

    Private Sub HitTest(ByVal Gift As PictureBox, ByVal Tag As Integer)
        Dim Column As String = Gift.Name(2)
        Dim Line As String = Gift.Name(1)
        Dim SurroundFlag As Boolean = False
        Gift.Tag *= 10
        Dim Real As Integer = Tag
        If ((CType(Me.Controls.Find("C" & Line & Column, False)(0), PictureBox).Tag = 10)) Then
            FormMess.Label1.Text = ("Navio com 1 espaço destruído!")
            FormMess.ShowDialog()
            HitLanchaPlayer += 1
            Label1.Text -= 1
            Exit Sub
        End If
        If ((Line - 1 >= 0 And Line - 1 <= 9)) Then
            If ((CType(Me.Controls.Find("C" & CInt(Line - 1) & Column, False)(0), PictureBox).Tag > 0)) Then
                For I As Integer = 1 To Tag
                    If (Line + I > 9) Then
                        Tag = I - 1
                        Exit For
                    End If
                Next
                Line += CInt(Tag)
                Dim L As Integer
                Dim Count As Integer = 0
                While (SurroundFlag = False)
                    If (CType(Me.Controls.Find("C" & Line & Column, False)(0), PictureBox).Tag = (Real * 10)) Then
                        If (Count = 0) Then
                            L = CInt(Line)
                        End If
                        Count += 1
                    Else
                        Count = 0
                    End If
                    If (Count = Real) Then
                        SurroundFlag = True
                        If (Count = 2) Then
                            HitSubPlayer += 1
                            Label42.Text -= 1
                        ElseIf (Count = 3) Then
                            HitBattlePlayer += 1
                            Label43.Text -= 1
                        ElseIf (Count = 4) Then
                            HitPortPlayer += 1
                            Label44.Text -= 1
                        End If
                        FormMess.Label1.Text = ("Navio com " & Real & " espaços destruído!")
                        FormMess.ShowDialog()
                    End If
                    Line -= 1
                    If (Line >= 0 And Line <= 9) Then
                        SurroundFlag = False
                    Else : SurroundFlag = True
                    End If
                End While
            End If
        End If
        If ((Line + 1 >= 0 And Line + 1 <= 9) And SurroundFlag = False) Then
            If ((CType(Me.Controls.Find("C" & CInt(Line + 1) & Column, False)(0), PictureBox).Tag > 0)) Then
                For I As Integer = 1 To Tag
                    If (Line + I > 9) Then
                        Tag = I - 1
                        Exit For
                    End If
                Next
                Line += CInt(Tag)
                Dim L As Integer
                Dim Count As Integer = 0
                While (SurroundFlag = False)
                    If (CType(Me.Controls.Find("C" & Line & Column, False)(0), PictureBox).Tag = (Real * 10)) Then
                        If (Count = 0) Then
                            L = CInt(Line)
                        End If
                        Count += 1
                    Else
                        Count = 0
                    End If
                    If (Count = Real) Then
                        SurroundFlag = True
                        If (Count = 2) Then
                            HitSubPlayer += 1
                            Label42.Text -= 1
                        ElseIf (Count = 3) Then
                            HitBattlePlayer += 1
                            Label43.Text -= 1
                        ElseIf (Count = 4) Then
                            HitPortPlayer += 1
                            Label44.Text -= 1
                        End If
                        FormMess.Label1.Text = ("Navio com " & Real & " espaços destruído!")
                        FormMess.ShowDialog()
                    End If
                    Line -= 1
                    If (Line >= 0 And Line <= 9) Then
                        SurroundFlag = False
                    Else : SurroundFlag = True
                    End If
                End While
            End If
        End If
        If (SurroundFlag = False) Then
            For I As Integer = 1 To Tag
                If (Column + I > 9) Then
                    Tag = I - 1
                    Exit For
                End If
            Next
            Column += CInt(Tag)
            Dim C As Integer
            Dim Count As Integer = 0
            While (SurroundFlag = False)
                If (CType(Me.Controls.Find("C" & Line & Column, False)(0), PictureBox).Tag = (Real * 10)) Then
                    If (Count = 0) Then
                        C = CInt(Column)
                    End If
                    Count += 1
                Else
                    Count = 0
                End If
                If (Count = Real) Then
                    SurroundFlag = True
                    If (Count = 2) Then
                        HitSubPlayer += 1
                        Label42.Text -= 1
                    ElseIf (Count = 3) Then
                        HitBattlePlayer += 1
                        Label43.Text -= 1
                    ElseIf (Count = 4) Then
                        HitPortPlayer += 1
                        Label44.Text -= 1
                    End If
                    FormMess.Label1.Text = ("Navio com " & Real & " espaços destruído!")
                    FormMess.ShowDialog()
                End If
                Column -= 1
                If (Column >= 0 And Column <= 9) Then
                    SurroundFlag = False
                Else : SurroundFlag = True
                End If
            End While
        End If

    End Sub

    Private Sub ShootToPc(ByVal sender As Object, ByVal e As System.EventArgs)

        If (ContLancha = 4 And ContSub = 3 And ContBattle = 2 And ContPort = 1) Then
            Label1.Visible = True
            Label42.Visible = True
            Label43.Visible = True
            Label44.Visible = True
            If (RotFlag = True) Then
                Rotation_Click(vbNull, e)
            End If
            If (Flag = True) Then
                If (sender.Tag > 0) Then
                    BigCount -= 1
                    sender.BackgroundImage = My.Resources.myhit
                    sender.Enabled = False
                    HitTest(sender, sender.Tag)
                    If (HitLanchaPlayer = 4 And HitSubPlayer = 3 And HitBattlePlayer = 2 And HitPortPlayer = 1) Then
                        FormMess.Label1.Text = ("Você ganhou!")
                        FormMess.ShowDialog()
                        Me.Close()
                        Application.Restart()
                        Exit Sub
                    End If
                Else
                    sender.backgroundImage = My.Resources.hit
                    sender.Enabled = False
                    Flag = False
                End If
            End If
            If (Flag = False) Then
                Computer()
                If (Bruh = 1) Then
                    FormMess.Label1.Text = ("O Computador ganhou!")
                    FormMess.ShowDialog()
                    Me.Close()
                    Application.Restart()
                    Exit Sub
                End If
            End If
        Else
            FormMess.Label1.Text = ("Coloque todos os navios!")
            FormMess.ShowDialog()
        End If
    End Sub

    Dim Rot As String = "d_fw"
    Private Sub Picture_MouseDown(ByVal sender As Object, ByVal e _
    As System.Windows.Forms.MouseEventArgs)
        If (Counting = 1) Then
            Form3.ShowDialog()
            Counting += 1
        End If
        Pop = sender.Name
        sender.Dodragdrop(sender.BackgroundImage, DragDropEffects.Move)
    End Sub

    Private Sub Picture_DragEnter(ByVal sender As Object, ByVal e _
As System.Windows.Forms.DragEventArgs)
        e.Effect = DragDropEffects.Move

    End Sub
    Dim Auxiliar As PictureBox
    Dim Line As String = String.Empty
    Dim Column As String = String.Empty

    Private Sub Picture_DragDrop(ByVal sender As Object, ByVal e _
    As System.Windows.Forms.DragEventArgs)
        Box = "Pic"
        Auxiliar = sender
        Line = sender.Name
        Column = Line(3)
        Line = Line(4)
        If (RotFlag = False) Then
            If (Pop(0) = "s" And ContSub < 3) Then
                If (CInt(Line) <= 8) Then
                    Space = 2
                    Dim Result As Boolean = Organize(CInt(Column), CInt(Line))
                    If (Result = True) Then
                        For K As Integer = 0 To 1
                            CType(Me.Controls.Find("Pic" & Column & CInt(Line + K), False)(0), PictureBox).BackgroundImage = My.Resources.ResourceManager.GetObject("s" & (K + 1) & "d_fw")
                            CType(Me.Controls.Find("Pic" & Column & CInt(Line + K), False)(0), PictureBox).Tag = 2
                        Next
                        ContSub += 1
                    Else
                        FormMess.Label1.Text = ("Colocação Inválida!")
                        FormMess.ShowDialog()
                    End If
                End If
            ElseIf (Pop(0) = "p" And ContLancha < 4) Then
                Space = 1
                Dim Result As Boolean = Organize(CInt(Column), CInt(Line))
                If (Result = True) Then
                    sender.BackgroundImage = e.Data.GetData(DataFormats.Bitmap)
                    sender.tag = 1
                    ContLancha += 1
                Else
                    FormMess.Label1.Text = ("Colocação Inválida!")
                    FormMess.ShowDialog()
                End If
            ElseIf (Pop(0) = "b" And ContBattle < 2) Then
                If (CInt(Line) <= 7) Then
                    Space = 3
                    Dim Result As Boolean = Organize(CInt(Column), CInt(Line))
                    If (Result = True) Then
                        For K As Integer = 0 To 2
                            CType(Me.Controls.Find("Pic" & Column & CInt(Line + K), False)(0), PictureBox).BackgroundImage = My.Resources.ResourceManager.GetObject("b" & (K + 1) & "d_fw")
                            CType(Me.Controls.Find("Pic" & Column & CInt(Line + K), False)(0), PictureBox).Tag = 3
                        Next
                        ContBattle += 1
                    Else
                        FormMess.Label1.Text = ("Colocação Inválida!")
                        FormMess.ShowDialog()
                    End If
                End If
            ElseIf (Pop(0) = "a" And ContPort < 1) Then
                If (CInt(Line) <= 6) Then
                    Space = 4
                    Dim Result As Boolean = Organize(CInt(Column), CInt(Line))
                    If (Result = True) Then
                        For K As Integer = 0 To 3
                            CType(Me.Controls.Find("Pic" & Column & CInt(Line + K), False)(0), PictureBox).BackgroundImage = My.Resources.ResourceManager.GetObject("a" & (K + 1) & "d_fw")
                            CType(Me.Controls.Find("Pic" & Column & CInt(Line + K), False)(0), PictureBox).Tag = 4
                        Next
                        ContPort += 1
                    Else
                        FormMess.Label1.Text = ("Colocação Inválida!")
                        FormMess.ShowDialog()
                    End If
                End If
            End If
        Else
            If (Pop(0) = "s" And ContSub < 3) Then
                If (CInt(Column) <= 8) Then
                    Space = 2
                    Dim Result As Boolean = RotationOrganize(CInt(Column), CInt(Line))
                    If (Result = True) Then
                        For K As Integer = 0 To 1
                            CType(Me.Controls.Find("Pic" & CInt(Column + K) & Line, False)(0), PictureBox).BackgroundImage = My.Resources.ResourceManager.GetObject("s" & (K + 1) & "r_fw")
                            CType(Me.Controls.Find("Pic" & CInt(Column + K) & Line, False)(0), PictureBox).Tag = 2
                        Next
                        ContSub += 1
                    Else
                        FormMess.Label1.Text = ("Colocação Inválida!")
                        FormMess.ShowDialog()
                    End If
                End If
            ElseIf (Pop(0) = "p" And ContLancha < 4) Then
                Space = 1
                Dim Result As Boolean = RotationOrganize(CInt(Column), CInt(Line))
                If (Result = True) Then
                    sender.BackgroundImage = My.Resources.ResourceManager.GetObject("p1r_fw")
                    sender.tag = 1
                    ContLancha += 1
                Else
                    FormMess.Label1.Text = ("Colocação Inválida!")
                    FormMess.ShowDialog()
                End If
            ElseIf (Pop(0) = "b" And ContBattle < 2) Then
                If (CInt(Column) <= 7) Then
                    Space = 3
                    Dim Result As Boolean = RotationOrganize(CInt(Column), CInt(Line))
                    If (Result = True) Then
                        For K As Integer = 0 To 2
                            CType(Me.Controls.Find("Pic" & CInt(Column + K) & Line, False)(0), PictureBox).BackgroundImage = My.Resources.ResourceManager.GetObject("b" & (K + 1) & "r_fw")
                            CType(Me.Controls.Find("Pic" & CInt(Column + K) & Line, False)(0), PictureBox).Tag = 3
                        Next
                        ContBattle += 1
                    Else
                        FormMess.Label1.Text = ("Colocação Inválida!")
                        FormMess.ShowDialog()
                    End If
                End If
            ElseIf (Pop(0) = "a" And ContPort < 1) Then
                If (CInt(Column) <= 6) Then
                    Space = 4
                    Dim Result As Boolean = RotationOrganize(CInt(Column), CInt(Line))
                    If (Result = True) Then
                        For K As Integer = 0 To 3
                            CType(Me.Controls.Find("Pic" & CInt(Column + K) & Line, False)(0), PictureBox).BackgroundImage = My.Resources.ResourceManager.GetObject("a" & (K + 1) & "r_fw")
                            CType(Me.Controls.Find("Pic" & CInt(Column + K) & Line, False)(0), PictureBox).Tag = 4
                        Next
                        ContPort += 1
                    Else
                        FormMess.Label1.Text = ("Colocação Inválida!")
                        FormMess.ShowDialog()
                    End If
                End If
            End If
        End If
    End Sub

    Private Function Organize(ByVal Cont2 As Integer, ByVal Cont1 As Integer)
        'Canto SUP ESQ
        Dim L As Integer = Cont2
        Dim C As Integer = Cont1
        If (Cont1 = Cont2 And Cont1 = 0) Then
            For J As Integer = 1 To 2
                For I As Integer = 1 To Space + 1
                    If (BloodyController = True) Then
                        CType(Me.Controls.Find(Box & L & C, False)(0), PictureBox).Tag = -3
                    End If
                    If (CType(Me.Controls.Find(Box & L & C, False)(0), PictureBox).Tag > 0) Then
                        Return False
                    End If
                    C += 1
                Next
                C = Cont1
                L += 1
            Next
            Return True
        End If
        'Canto SUP DIR
        If ((Pop(0) = "s" And C = 8 And L = 0) Or (Pop(0) = "b" And C = 7 And L = 0) Or (Pop(0) = "a" And C = 6 And L = 0) Or (Pop(0) = "p" And C = 9 And L = 0)) Then
            C -= 1
            For J As Integer = 1 To 2
                For I As Integer = 1 To Space + 1
                    If (BloodyController = True) Then
                        CType(Me.Controls.Find(Box & L & C, False)(0), PictureBox).Tag = -3
                    End If
                    If (CType(Me.Controls.Find(Box & L & C, False)(0), PictureBox).Tag > 0) Then
                        Return False
                    End If
                    C += 1
                Next
                L += 1
                C = Cont1 - 1
            Next
            Return True
        End If

        'Canto INF DIR
        If ((Pop(0) = "s" And C = 8 And L = 9) Or (Pop(0) = "b" And C = 7 And L = 9) Or (Pop(0) = "a" And C = 6 And L = 9) Or (Pop(0) = "p" And C = 9 And L = 9)) Then
            C -= 1
            For J As Integer = 1 To 2
                For I As Integer = 1 To Space + 1
                    If (BloodyController = True) Then
                        CType(Me.Controls.Find(Box & L & C, False)(0), PictureBox).Tag = -3
                    End If
                    If (CType(Me.Controls.Find(Box & L & C, False)(0), PictureBox).Tag > 0) Then
                        Return False
                    End If
                    C += 1
                Next
                L -= 1
                C = Cont1 - 1
            Next
            Return True
        End If

        'Canto INF ESQ
        If (Cont1 = 0 And Cont2 = 9) Then
            For J As Integer = 1 To 2
                For I As Integer = 1 To Space + 1
                    If (BloodyController = True) Then
                        CType(Me.Controls.Find(Box & L & C, False)(0), PictureBox).Tag = -3
                    End If
                    If (CType(Me.Controls.Find(Box & L & C, False)(0), PictureBox).Tag > 0) Then
                        Return False
                    End If
                    C += 1
                Next
                L -= 1
                C = Cont1
            Next
            Return True
        End If

        'Casos do Lado Esquerdo
        If (Cont1 = 0 And Cont2 >= 1 And Cont2 <= 8) Then
            L -= 1
            For J As Integer = 1 To 3
                For I As Integer = 1 To Space + 1
                    If (BloodyController = True) Then
                        CType(Me.Controls.Find(Box & L & C, False)(0), PictureBox).Tag = -3
                    End If
                    If (CType(Me.Controls.Find(Box & L & C, False)(0), PictureBox).Tag > 0) Then
                        Return False
                    End If
                    C += 1
                Next
                L += 1
                C = Cont1
            Next
            Return True
        End If

        'Casos do Lado Direito
        If ((L >= 1 And L <= 8) And (Pop(0) = "s" And C = 8) Or (Pop(0) = "b" And C = 7) Or (Pop(0) = "a" And C = 6) Or (Pop(0) = "p" And C = 9)) Then
            L -= 1
            C -= 1
            For J As Integer = 1 To 3
                For I As Integer = 1 To Space + 1
                    If (BloodyController = True) Then
                        CType(Me.Controls.Find(Box & L & C, False)(0), PictureBox).Tag = -3
                    End If
                    If (CType(Me.Controls.Find(Box & L & C, False)(0), PictureBox).Tag > 0) Then
                        Return False
                    End If
                    C += 1
                Next
                L += 1
                C = Cont1 - 1
            Next
            Return True
        End If

        'Casos de Cima
        If (Cont2 = 0 And (Cont1 >= 1 And Cont1 <= 8)) Then
            C -= 1
            For J As Integer = 1 To 2
                For I As Integer = 1 To Space + 2
                    If (BloodyController = True) Then
                        CType(Me.Controls.Find(Box & L & C, False)(0), PictureBox).Tag = -3
                    End If
                    If (CType(Me.Controls.Find(Box & L & C, False)(0), PictureBox).Tag > 0) Then
                        Return False
                    End If
                    C += 1
                Next
                L += 1
                C = Cont1 - 1
            Next
            Return True
        End If

        'Caso de Baixo
        If (Cont2 = 9 And Cont1 >= 1 And Cont1 <= 8) Then
            C -= 1
            For J As Integer = 1 To 2
                For I As Integer = 1 To Space + 2
                    If (BloodyController = True) Then
                        CType(Me.Controls.Find(Box & L & C, False)(0), PictureBox).Tag = -3
                    End If
                    If (CType(Me.Controls.Find(Box & L & C, False)(0), PictureBox).Tag > 0) Then
                        Return False
                    End If
                    C += 1
                Next
                L -= 1
                C = Cont1 - 1
            Next
            Return True
        End If

        'Caso mais geral
        If ((Cont1 >= 1 And Cont1 <= 8 And Cont2 >= 1 And Cont2 <= 8)) Then
            L -= 1
            C -= 1
            For J As Integer = 1 To 3
                For I As Integer = 1 To Space + 2
                    If (BloodyController = True) Then
                        CType(Me.Controls.Find(Box & L & C, False)(0), PictureBox).Tag = -3
                    End If
                    If (CType(Me.Controls.Find(Box & L & C, False)(0), PictureBox).Tag > 0) Then
                        Return False
                    End If
                    C += 1
                Next
                L += 1
                C = Cont1 - 1
            Next
            Return True
        End If

        Return True
    End Function

    Private Function RotationOrganize(ByVal Cont2 As Integer, ByVal Cont1 As Integer)
        'Canto SUP ESQ
        Dim L As Integer = Cont2
        Dim C As Integer = Cont1
        If (Cont1 = Cont2 And Cont1 = 0) Then
            For J As Integer = 1 To Space + 1
                For I As Integer = 1 To 2
                    If (CType(Me.Controls.Find(Box & L & C, False)(0), PictureBox).Tag > 0) Then
                        Return False
                    End If
                    C += 1
                Next
                C = Cont1
                L += 1
            Next
            Return True
        End If
        'Canto SUP DIR
        If (Cont1 = 9 And Cont2 = 0) Then
            For J As Integer = 1 To Space + 1
                For I As Integer = 1 To 2
                    If (CType(Me.Controls.Find(Box & L & C, False)(0), PictureBox).Tag > 0) Then
                        Return False
                    End If
                    C -= 1
                Next
                L += 1
                C = Cont1
            Next
            Return True
        End If

        'Canto INF DIR
        If ((Pop(0) = "s" And C = 9 And L = 8) Or (Pop(0) = "b" And C = 9 And L = 7) Or (Pop(0) = "a" And C = 9 And L = 6) Or (Pop(0) = "p" And C = 9 And L = 9)) Then
            L -= 1
            For J As Integer = 1 To Space + 1
                For I As Integer = 1 To 2
                    If (CType(Me.Controls.Find(Box & L & C, False)(0), PictureBox).Tag > 0) Then
                        Return False
                    End If
                    C -= 1
                Next
                L += 1
                C = Cont1
            Next
            Return True
        End If

        'Canto INF ESQ
        If ((Pop(0) = "s" And C = 0 And L = 8) Or (Pop(0) = "b" And C = 0 And L = 7) Or (Pop(0) = "a" And C = 0 And L = 6) Or (Pop(0) = "p" And C = 0 And L = 9)) Then
            L -= 1
            For J As Integer = 1 To Space + 1
                For I As Integer = 1 To 2
                    If (CType(Me.Controls.Find(Box & L & C, False)(0), PictureBox).Tag > 0) Then
                        Return False
                    End If
                    C += 1
                Next
                L += 1
                C = Cont1
            Next
            Return True
        End If

        'Casos do Lado Esquerdo
        If (Cont1 = 0 And Cont2 >= 1 And Cont2 <= 8) Then
            L -= 1
            For J As Integer = 1 To Space + 2
                For I As Integer = 1 To 2
                    If (CType(Me.Controls.Find(Box & L & C, False)(0), PictureBox).Tag > 0) Then
                        Return False
                    End If
                    C += 1
                Next
                L += 1
                C = Cont1
            Next
            Return True
        End If

        'Casos do Lado Direito
        If ((L >= 1 And L <= 8) And (C = 9)) Then
            L -= 1
            For J As Integer = 1 To Space + 2
                For I As Integer = 1 To 2
                    If (CType(Me.Controls.Find(Box & L & C, False)(0), PictureBox).Tag > 0) Then
                        Return False
                    End If
                    C -= 1
                Next
                L += 1
                C = Cont1
            Next
            Return True
        End If

        'Casos de Cima
        If (Cont2 = 0 And (Cont1 >= 1 And Cont1 <= 8)) Then
            C -= 1
            For J As Integer = 1 To Space + 1
                For I As Integer = 1 To 3
                    If (CType(Me.Controls.Find(Box & L & C, False)(0), PictureBox).Tag > 0) Then
                        Return False
                    End If
                    C += 1
                Next
                L += 1
                C = Cont1 - 1
            Next
            Return True
        End If

        'Caso de Baixo
        If ((Pop(0) = "s" And L = 8) Or (Pop(0) = "b" And L = 7) Or (Pop(0) = "a" And L = 6) Or (Pop(0) = "p" And L = 9)) Then
            L -= 1
            C -= 1
            For J As Integer = 1 To Space + 1
                For I As Integer = 1 To 3
                    If (CType(Me.Controls.Find(Box & L & C, False)(0), PictureBox).Tag > 0) Then
                        Return False
                    End If
                    C += 1
                Next
                L += 1
                C = Cont1 - 1
            Next
            Return True
        End If

        'Caso mais geral
        If ((Cont1 >= 1 And Cont1 <= 8 And Cont2 >= 1 And Cont2 <= 8)) Then
            L -= 1
            C -= 1
            For J As Integer = 1 To Space + 2
                For I As Integer = 1 To 3
                    If (CType(Me.Controls.Find(Box & L & C, False)(0), PictureBox).Tag > 0) Then
                        Return False
                    End If
                    C += 1
                Next
                L += 1
                C = Cont1 - 1
            Next
            Return True
        End If
        Return True
    End Function
    Dim RotFlag As Boolean = False
    Private Sub Rotation_Click(sender As Object, e As EventArgs) Handles Rotation.Click
        If (RotFlag = False) Then
            RotFlag = True
            For I = 1 To 4
                CType(Me.Controls.Find("Lab" & I, False)(0), Label).Text = "R"
            Next
        Else
            For I = 1 To 4
                CType(Me.Controls.Find("Lab" & I, False)(0), Label).Text = ""
            Next
            RotFlag = False
        End If
    End Sub
    Dim ComputerLastShoot As Integer = 0
    Dim Linha As Integer
    Dim Coluna As Integer
    Dim RealTag As Integer
    Dim BlablaLine As Integer
    Dim BlablaCol As Integer
    Dim FunctionFurni As Integer = 0
    Dim Count As Integer = 0
    Dim Bruh As Integer = 0

    Private Sub Computer()
        While (ComputerLastShoot = 1 And Flag = False)
            If (FunctionFurni = 1) Then
                ComputerInteligent(Linha, Coluna)
            ElseIf (FunctionFurni = 0) Then
                ComputerInteligentRot(Linha, Coluna)
            End If
        End While
        Count = 0
        FunctionFurni = 10
        If (ComputerLastShoot = 0) Then
            While (Count = 0)
                Dim Column As Integer = CInt((9 * Rnd()))
                Dim Line As Integer = CInt((9 * Rnd()))
                If (CType(Me.Controls.Find("Pic" & Line & Column, False)(0), PictureBox).Tag > 0) Then
                    Flag = False
                    CType(Me.Controls.Find("Pic" & Line & Column, False)(0), PictureBox).BackgroundImage = My.Resources.myhit
                    Count = 1
                    Linha = Line
                    Coluna = Column
                    If (CType(Me.Controls.Find("Pic" & Line & Column, False)(0), PictureBox).Tag = 1) Then
                        'ComputerLastShoot = 0
                        ComputerLastShoot = 1
                        RealTag = CType(Me.Controls.Find("Pic" & Line & Column, False)(0), PictureBox).Tag
                        CType(Me.Controls.Find("Pic" & Line & Column, False)(0), PictureBox).Tag = -3
                        BlablaLine = Linha
                        BlablaCol = Coluna
                        FunctionFurni = 0
                        ComputerInteligent(Linha, Coluna)
                        CType(Me.Controls.Find("Pic" & Line & Column, False)(0), PictureBox).BackgroundImage = My.Resources.myhit
                    ElseIf (CType(Me.Controls.Find("Pic" & Line & Column, False)(0), PictureBox).Tag <> 1) Then
                        If (Column + 1 <= 9 And FunctionFurni = 10) Then
                            If (CType(Me.Controls.Find("Pic" & Line & CInt(Column + 1), False)(0), PictureBox).Tag > 0) Then
                                ComputerLastShoot = 1
                                RealTag = CType(Me.Controls.Find("Pic" & Line & Column, False)(0), PictureBox).Tag
                                CType(Me.Controls.Find("Pic" & Line & Column, False)(0), PictureBox).Tag = -3
                                BlablaLine = Linha
                                BlablaCol = Coluna
                                FunctionFurni = 1
                                ComputerInteligent(Linha, Coluna)
                            End If
                        End If
                        If (Column - 1 >= 0 And FunctionFurni = 10) Then
                            If (CType(Me.Controls.Find("Pic" & Line & CInt(Column - 1), False)(0), PictureBox).Tag > 0) Then
                                ComputerLastShoot = 1
                                RealTag = CType(Me.Controls.Find("Pic" & Line & Column, False)(0), PictureBox).Tag
                                CType(Me.Controls.Find("Pic" & Line & Column, False)(0), PictureBox).Tag = -3
                                BlablaLine = Linha
                                BlablaCol = Coluna
                                FunctionFurni = 1
                                ComputerInteligent(Linha, Coluna)
                            End If
                        End If
                        If (Line + 1 <= 9 And FunctionFurni = 10) Then
                            If (CType(Me.Controls.Find("Pic" & CInt(Line + 1) & Column, False)(0), PictureBox).Tag > 0) Then
                                ComputerLastShoot = 1
                                RealTag = CType(Me.Controls.Find("Pic" & Line & Column, False)(0), PictureBox).Tag
                                CType(Me.Controls.Find("Pic" & Line & Column, False)(0), PictureBox).Tag = -3
                                BlablaLine = Linha
                                BlablaCol = Coluna
                                FunctionFurni = 0
                                ComputerInteligentRot(Linha, Coluna)
                            End If
                        End If
                        If (Line - 1 >= 0 And FunctionFurni = 10) Then
                            If (CType(Me.Controls.Find("Pic" & CInt(Line - 1) & Column, False)(0), PictureBox).Tag > 0) Then
                                ComputerLastShoot = 1
                                RealTag = CType(Me.Controls.Find("Pic" & Line & Column, False)(0), PictureBox).Tag
                                CType(Me.Controls.Find("Pic" & Line & Column, False)(0), PictureBox).Tag = -3
                                BlablaLine = Linha
                                BlablaCol = Coluna
                                FunctionFurni = 0
                                ComputerInteligentRot(Linha, Coluna)
                            End If
                        End If
                    End If
                    'CType(Me.Controls.Find("Pic" & Line & Column, False)(0), PictureBox).Tag = -1
                ElseIf (CType(Me.Controls.Find("Pic" & Line & Column, False)(0), PictureBox).Tag = 0) Then
                    CType(Me.Controls.Find("Pic" & Line & Column, False)(0), PictureBox).BackgroundImage = My.Resources.hit
                    CType(Me.Controls.Find("Pic" & Line & Column, False)(0), PictureBox).Tag = -2
                    Flag = True
                    Count = 1
                    FunctionFurni = 10
                End If
                If (HitLancha = 4 And HitSub = 3 And HitBattle = 2 And HitPort = 1) Then
                    Bruh = 1
                    Exit Sub
                End If
            End While
        End If

        While (ComputerLastShoot = 1 And Flag = False)
            If (FunctionFurni = 1) Then
                ComputerInteligent(Linha, Coluna)
            ElseIf (FunctionFurni = 0) Then
                ComputerInteligentRot(Linha, Coluna)
            End If
        End While
        If (FunctionFurni = -1) Then
            Computer()
        End If
    End Sub
    Dim Diretiony As String = String.Empty
    Dim AuxLiney As Integer
    Dim AuxColumny As Integer
    Dim BloddyCount As Integer = 1
    Dim Helper As Integer = 0


    Dim UniversalLine As Integer
    Dim UniversalColumn As Integer
    Private Sub ComputerInteligentRot(ByVal Liney As Integer, ByVal Columny As Integer)
        Helper = 0
        Dim L1 As Integer = AuxLiney
        Dim C1 As Integer = AuxColumny
        BloodyController = False

        If (Diretiony = "d1") Then
            If (CType(Me.Controls.Find("Pic" & CInt(AuxLiney - 1) & AuxColumny, False)(0), PictureBox).Tag > 0) Then
                L1 = AuxLiney
                C1 = AuxColumny
                BlablaLine = AuxLiney - 1
                BlablaCol = AuxColumny
                CType(Me.Controls.Find("Pic" & CInt(AuxLiney - 1) & AuxColumny, False)(0), PictureBox).Tag = -3
                BloddyCount += 1
                CType(Me.Controls.Find("Pic" & CInt(AuxLiney - 1) & AuxColumny, False)(0), PictureBox).BackgroundImage = My.Resources.myhit
                Helper = 1
                If (AuxLiney - 2 >= 0) Then
                    If (CType(Me.Controls.Find("Pic" & CInt(AuxLiney - 2) & AuxColumny, False)(0), PictureBox).Tag <> -2) Then
                        AuxLiney -= 1
                    Else
                        AuxLiney = Linha
                        AuxColumny = Coluna
                        Diretiony = "d2"
                    End If
                Else
                    AuxLiney = Linha
                    AuxColumny = Coluna
                    Diretiony = "d2"
                    Helper = 2
                End If
            Else
                AuxLiney = Linha
                AuxColumny = Coluna
                Diretiony = "d2"
                CType(Me.Controls.Find("Pic" & CInt(L1 - 1) & C1, False)(0), PictureBox).Tag = -2
                CType(Me.Controls.Find("Pic" & CInt(L1 - 1) & C1, False)(0), PictureBox).BackgroundImage = My.Resources.hit
                Helper = 0
            End If
        ElseIf (Diretiony = "d2") Then
            If (CType(Me.Controls.Find("Pic" & CInt(AuxLiney + 1) & AuxColumny, False)(0), PictureBox).Tag > 0) Then
                CType(Me.Controls.Find("Pic" & CInt(AuxLiney + 1) & AuxColumny, False)(0), PictureBox).Tag = -3
                BloddyCount += 1
                L1 = AuxLiney
                C1 = AuxColumny
                CType(Me.Controls.Find("Pic" & CInt(AuxLiney + 1) & AuxColumny, False)(0), PictureBox).BackgroundImage = My.Resources.myhit
                Helper = 1
                If (AuxLiney + 2 <= 9) Then
                    If (CType(Me.Controls.Find("Pic" & CInt(AuxLiney + 2) & AuxColumny, False)(0), PictureBox).Tag <> -2) Then
                        AuxLiney += +1
                    Else
                        Diretiony = "d1"
                        AuxLiney = Linha
                        AuxColumny = Coluna
                    End If
                Else
                    AuxLiney = Linha
                    AuxColumny = Coluna
                    Diretiony = "d1"
                    Helper = 2
                End If
            Else
                AuxLiney = Linha
                AuxColumny = Coluna
                Diretiony = "d1"
                CType(Me.Controls.Find("Pic" & CInt(L1 + 1) & C1, False)(0), PictureBox).Tag = -2
                CType(Me.Controls.Find("Pic" & CInt(L1 + 1) & C1, False)(0), PictureBox).BackgroundImage = My.Resources.hit
                Helper = 0
            End If
        ElseIf (Liney - 1 >= 0) Then
            If (CType(Me.Controls.Find("Pic" & CInt(Liney - 1) & Columny, False)(0), PictureBox).Tag > 0) Then
                CType(Me.Controls.Find("Pic" & CInt(Liney - 1) & Columny, False)(0), PictureBox).Tag = -3
                BloddyCount += 1
                BlablaLine = Liney - 1
                BlablaCol = Columny
                CType(Me.Controls.Find("Pic" & CInt(Liney - 1) & Columny, False)(0), PictureBox).BackgroundImage = My.Resources.myhit
                Helper = 1
                If (Liney - 2 >= 0) Then
                    If (CType(Me.Controls.Find("Pic" & CInt(Liney - 2) & Columny, False)(0), PictureBox).Tag <> -2) Then
                        Diretiony = "d1"
                        AuxLiney = Liney - 1
                        AuxColumny = Columny
                    Else
                        Diretiony = "d2"
                        AuxLiney = Linha
                        AuxColumny = Coluna
                    End If
                Else
                    AuxLiney = Linha
                    AuxColumny = Coluna
                    Diretiony = "d2"
                    Helper = 2
                End If
            Else
                CType(Me.Controls.Find("Pic" & CInt(Liney - 1) & Columny, False)(0), PictureBox).BackgroundImage = My.Resources.hit
                If (CType(Me.Controls.Find("Pic" & CInt(Liney - 1) & Columny, False)(0), PictureBox).Tag = -2) Then
                    Diretiony = "d2"
                    Helper = 2
                    AuxLiney = Linha
                    AuxColumny = Coluna
                Else
                    Helper = 0
                    Diretiony = "d2"
                    AuxLiney = Linha
                    AuxColumny = Coluna
                End If
                CType(Me.Controls.Find("Pic" & CInt(Liney - 1) & Columny, False)(0), PictureBox).Tag = -2
            End If
        ElseIf (Liney + 1 <= 9) Then
            If (CType(Me.Controls.Find("Pic" & CInt(Liney + 1) & Columny, False)(0), PictureBox).Tag > 0) Then
                BloddyCount += 1
                CType(Me.Controls.Find("Pic" & CInt(Liney + 1) & Columny, False)(0), PictureBox).BackgroundImage = My.Resources.myhit
                Helper = 1
                CType(Me.Controls.Find("Pic" & CInt(Liney + 1) & Columny, False)(0), PictureBox).Tag = -3
                If (Liney + 2 <= 9) Then
                    If (CType(Me.Controls.Find("Pic" & CInt(Liney + 2) & Columny, False)(0), PictureBox).Tag <> -2) Then
                        Diretiony = "d2"
                        AuxLiney = Liney + 1
                        AuxColumny = Columny
                    Else
                        Diretiony = "d1"
                        AuxLiney = Linha
                        AuxColumny = Coluna
                    End If
                Else
                    AuxLiney = Linha
                    AuxColumny = Coluna
                    Diretiony = "d1"
                    Helper = 2
                End If
            Else
                CType(Me.Controls.Find("Pic" & CInt(Liney + 1) & Columny, False)(0), PictureBox).BackgroundImage = My.Resources.hit
                If (CType(Me.Controls.Find("Pic" & CInt(Liney + 1) & Columny, False)(0), PictureBox).Tag = -2) Then
                    Diretiony = "d1"
                    Helper = 2
                    AuxLiney = Linha
                    AuxColumny = Coluna
                Else
                    Helper = 0
                    Diretiony = "d1"
                    AuxLiney = Linha
                    AuxColumny = Coluna
                    CType(Me.Controls.Find("Pic" & CInt(AuxLiney + 1) & Columny, False)(0), PictureBox).Tag = -2
                End If
            End If
        End If
        If (BloddyCount = RealTag) Then
            FormMess.Label1.Text = ("Navio de " & RealTag & " destruído pelo computador!")
            FormMess.ShowDialog()
            FunctionFurni = -1
            If (RealTag = 2) Then
                Pop = "s"
                HitSub += 1
            ElseIf (RealTag = 3) Then
                Pop = "b"
                HitBattle += 1
            ElseIf (RealTag = 4) Then
                Pop = "a"
                HitPort += 1
            End If
            BloodyController = True
            Space = RealTag
            RotationOrganize(BlablaLine, BlablaCol)
            ComputerLastShoot = 0
            BloddyCount = 1
            Diretiony = String.Empty
            Flag = True
            Count = 2
        ElseIf (Helper = 2) Then
            ComputerInteligentRot(1, 1)
        ElseIf (Helper = 0) Then
            Flag = True
        End If
    End Sub

    Private Sub ComputerInteligent(ByVal Liney As Integer, ByVal Columny As Integer)
        Helper = 0
        Dim L1 As Integer = AuxLiney
        Dim C1 As Integer = AuxColumny
        BloodyController = False

        If (Diretiony = "d1") Then
            If (CType(Me.Controls.Find("Pic" & AuxLiney & CInt(AuxColumny - 1), False)(0), PictureBox).Tag > 0) Then
                L1 = AuxLiney
                C1 = AuxColumny
                BlablaLine = AuxLiney
                BlablaCol = AuxColumny - 1
                CType(Me.Controls.Find("Pic" & AuxLiney & CInt(AuxColumny - 1), False)(0), PictureBox).Tag = -3
                BloddyCount += 1
                CType(Me.Controls.Find("Pic" & AuxLiney & CInt(AuxColumny - 1), False)(0), PictureBox).BackgroundImage = My.Resources.myhit
                Helper = 1
                If (AuxColumny - 2 >= 0) Then
                    If (CType(Me.Controls.Find("Pic" & AuxLiney & CInt(AuxColumny - 2), False)(0), PictureBox).Tag <> -2) Then
                        AuxColumny -= 1
                    Else
                        AuxLiney = Linha
                        AuxColumny = Coluna
                        Diretiony = "d2"
                    End If
                Else
                    AuxLiney = Linha
                    AuxColumny = Coluna
                    Diretiony = "d2"
                    Helper = 2
                End If
            Else
                AuxLiney = Linha
                AuxColumny = Coluna
                Diretiony = "d2"
                CType(Me.Controls.Find("Pic" & L1 & CInt(C1 - 1), False)(0), PictureBox).Tag = -2
                CType(Me.Controls.Find("Pic" & L1 & CInt(C1 - 1), False)(0), PictureBox).BackgroundImage = My.Resources.hit
                Helper = 0
            End If
        ElseIf (Diretiony = "d2") Then
            If (CType(Me.Controls.Find("Pic" & AuxLiney & CInt(AuxColumny + 1), False)(0), PictureBox).Tag > 0) Then
                CType(Me.Controls.Find("Pic" & AuxLiney & CInt(AuxColumny + 1), False)(0), PictureBox).Tag = -3
                BloddyCount += 1
                L1 = AuxLiney
                C1 = AuxColumny
                CType(Me.Controls.Find("Pic" & AuxLiney & CInt(AuxColumny + 1), False)(0), PictureBox).BackgroundImage = My.Resources.myhit
                Helper = 1
                If (AuxColumny + 2 <= 9) Then
                    If (CType(Me.Controls.Find("Pic" & AuxLiney & CInt(AuxColumny + 2), False)(0), PictureBox).Tag <> -2) Then
                        AuxColumny += +1
                    Else
                        Diretiony = "d1"
                        AuxLiney = Linha
                        AuxColumny = Coluna
                    End If
                Else
                    AuxLiney = Linha
                    AuxColumny = Coluna
                    Diretiony = "d1"
                    Helper = 2
                End If
            Else
                AuxLiney = Linha
                AuxColumny = Coluna
                Diretiony = "d1"
                CType(Me.Controls.Find("Pic" & L1 & CInt(C1 + 1), False)(0), PictureBox).Tag = -2
                CType(Me.Controls.Find("Pic" & L1 & CInt(C1 + 1), False)(0), PictureBox).BackgroundImage = My.Resources.hit
                Helper = 0
            End If
        ElseIf (Columny - 1 >= 0) Then
            If (CType(Me.Controls.Find("Pic" & Liney & CInt(Columny - 1), False)(0), PictureBox).Tag > 0) Then
                CType(Me.Controls.Find("Pic" & Liney & CInt(Columny - 1), False)(0), PictureBox).Tag = -3
                BloddyCount += 1
                BlablaLine = Liney
                BlablaCol = Columny - 1
                CType(Me.Controls.Find("Pic" & Liney & CInt(Columny - 1), False)(0), PictureBox).BackgroundImage = My.Resources.myhit
                Helper = 1
                If (Columny - 2 >= 0) Then
                    If (CType(Me.Controls.Find("Pic" & Liney & CInt(Columny - 2), False)(0), PictureBox).Tag <> -2) Then
                        Diretiony = "d1"
                        AuxLiney = Liney
                        AuxColumny = Columny - 1
                    Else
                        Diretiony = "d2"
                        AuxLiney = Linha
                        AuxColumny = Coluna
                    End If
                Else
                    AuxLiney = Linha
                    AuxColumny = Coluna
                    Diretiony = "d2"
                    Helper = 2
                End If
            Else
                CType(Me.Controls.Find("Pic" & Liney & CInt(Columny - 1), False)(0), PictureBox).BackgroundImage = My.Resources.hit
                If (CType(Me.Controls.Find("Pic" & Liney & CInt(Columny - 1), False)(0), PictureBox).Tag = -2) Then
                    Diretiony = "d2"
                    Helper = 2
                    AuxLiney = Linha
                    AuxColumny = Coluna
                Else
                    Helper = 0
                    Diretiony = "d2"
                    AuxLiney = Linha
                    AuxColumny = Coluna
                End If
                CType(Me.Controls.Find("Pic" & Liney & CInt(Columny - 1), False)(0), PictureBox).Tag = -2
            End If
        ElseIf (Columny + 1 <= 9) Then
            If (CType(Me.Controls.Find("Pic" & Liney & CInt(Columny + 1), False)(0), PictureBox).Tag > 0) Then
                BloddyCount += 1
                CType(Me.Controls.Find("Pic" & Liney & CInt(Columny + 1), False)(0), PictureBox).BackgroundImage = My.Resources.myhit
                Helper = 1
                CType(Me.Controls.Find("Pic" & Liney & CInt(Columny + 1), False)(0), PictureBox).Tag = -3
                If (Columny + 2 <= 9) Then
                    If (CType(Me.Controls.Find("Pic" & Liney & CInt(Columny + 2), False)(0), PictureBox).Tag <> -2) Then
                        Diretiony = "d2"
                        AuxLiney = Liney
                        AuxColumny = Columny + 1
                    Else
                        Diretiony = "d1"
                        AuxLiney = Linha
                        AuxColumny = Coluna
                    End If
                Else
                    AuxLiney = Linha
                    AuxColumny = Coluna
                    Diretiony = "d1"
                    Helper = 2
                End If
            Else
                CType(Me.Controls.Find("Pic" & Liney & CInt(Columny + 1), False)(0), PictureBox).BackgroundImage = My.Resources.hit
                If (CType(Me.Controls.Find("Pic" & Liney & CInt(Columny + 1), False)(0), PictureBox).Tag = -2) Then
                    Diretiony = "d1"
                    Helper = 2
                    AuxLiney = Linha
                    AuxColumny = Coluna
                Else
                    Helper = 0
                    Diretiony = "d1"
                    AuxLiney = Linha
                    AuxColumny = Coluna
                    CType(Me.Controls.Find("Pic" & AuxLiney & CInt(Columny + 1), False)(0), PictureBox).Tag = -2
                End If
            End If
        End If
        If (BloddyCount = RealTag) Then
            FormMess.Label1.Text = ("Navio de " & RealTag & " destruído pelo computador!")
            FormMess.ShowDialog()
            FunctionFurni = -1
            If (RealTag = 2) Then
                Pop = "s"
                HitSub += 1
            ElseIf (RealTag = 3) Then
                Pop = "b"
                HitBattle += 1
            ElseIf (RealTag = 4) Then
                Pop = "a"
                HitPort += 1
            Else
                HitLancha += 1
            End If
            BloodyController = True
            Space = RealTag
            Organize(BlablaLine, BlablaCol)
            ComputerLastShoot = 0
            BloddyCount = 1
            Diretiony = String.Empty
            Flag = True
            Count = 2
        ElseIf (Helper = 2) Then
            ComputerInteligent(1, 1)
        ElseIf (Helper = 0) Then
            Flag = True
        End If
    End Sub

End Class
