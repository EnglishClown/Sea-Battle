﻿Public Class Form2
    Dim a As Integer
    Public Form As Form1
    Dim sender As Object
    Dim e As EventArgs

    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Form = New Form1
        Me.WindowState = FormWindowState.Maximized
        Me.FormBorderStyle = Windows.Forms.FormBorderStyle.None
        Dim Wt As Integer = Screen.PrimaryScreen.Bounds.Width
        Dim Ht As Integer = Screen.PrimaryScreen.Bounds.Height
        Me.Size = New Drawing.Size(Wt, Ht)
        PictureBox1.Location = New Point((CInt(Wt / 2) - 176), (CInt(Ht / 2) - 150))
        'Form1.Hide()
    End Sub

    Private Sub Form1_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles MyBase.KeyDown
        If e.KeyCode = Keys.Escape Then Me.Close()
    End Sub

    Private Sub Pliz(sender As Object, e As EventArgs) Handles MyBase.Shown
        Form.WindowState = FormWindowState.Minimized
        Me.BringToFront()
        Form.Show()
        Form.WindowState = FormWindowState.Normal
        Form.SendToBack()
    End Sub

    Private Sub EnterForm()
        Me.Hide()
        Form.BringToFront()
    End Sub

    Dim Count As Integer = 0
    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Count += 1
        If (Count = 1) Then
            Timer1.Stop()
            EnterForm()
        End If
    End Sub
End Class